
import React, { useCallback } from "react";
import { Alert, StyleSheet, Text, View,Linking, Image, ImageBackground,Button} from 'react-native';

const supportedURL = "https://www.crunchyroll.com/pt-br/attack-on-titan?utm_source=editorial_cr&utm_medium=top-bar&utm_campaign=aot_pt&referrer=editorial_cr_top-bar_aot_pt_avod_20220130";
const supportedURL2 = "https://youtu.be/UPKQtzBGhlI";
const supportedURL3 = "https://www.crunchyroll.com/pt-br/demon-slayer-kimetsu-no-yaiba";
const supportedURL4 = "https://youtu.be/BArxCLOOVwc";
const OpenURLButton = ({ url, children }) => {
    const handlePress = useCallback(async () => {
      const supported = await Linking.canOpenURL(url);
  
      if (supported) {
         Linking.openURL(url);
      } else {
        Alert.alert(`Don't know how to open this URL: ${url}`);
      }
    }, [url]);
    return <Button title={children} onPress={handlePress} />;
};
const style = StyleSheet.create({
    hero: {
        height: '80vh',
        width: '100vw',
        alignItems: 'center',
        justifyContent: 'center',
    },
    tBody: {
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#000000',
    },
    heroText: {
        color: '#FFFFFF',
        fontFamily: 'sans-serif',
        fontSize: '8vw',
    },
    herosubText: {
        color: '#FFFFFF',
        fontFamily: 'sans-serif',
        fontSize: '4vw',
    },
    divq: {
        backgroundColor: 'rgba(0,0,0,0.5)',
        alignItems: 'center',
        width: '100vw',
    },
    textEx: {
        color: '#FFFFFF',
        fontFamily: 'sans-serif',
        fontSize: 15,
        margin: '10px'
    },
    imgEx: {
        width: '80vw',
        height: '45vw',
        marginBottom: 20,
    },
    divTr: {
        alignItems: 'center',
        paddingBottom: 20,
        width: '90vw',
        marginTop: '5px',
        marginBottom: '5px',
        backgroundColor: '#212121'
    },
})
export default function Home() {

    return (

        <View style={{ flex: 1 }}>

            <View style={style.tBody}>
                <View>
                    <ImageBackground style={style.hero} source={{ uri: 'https://i.pinimg.com/originals/8c/45/a5/8c45a59c9a6239012787c3cbb50f6f24.gif' }}>
                        <View style={style.divq}>
                            <Text style={style.heroText}>ANIMALL</Text>
                            <Text style={style.herosubText}>OS MELHORES ANIMES DA TEMPORADA</Text>
                        </View>
                    </ImageBackground>
                </View>

                <View style={{height:'10vh',width: '100vw',backgroundColor:'#303030'}}/>

                <View style={style.divTr}>
                    <Text style={style.textEx}>Attack on Titan - Seazon Final</Text>
                    <Image style={style.imgEx} source='https://ontvoficial.com.br/wp-content/uploads/2020/09/22181918342323.jpg' />
                    <OpenURLButton style={style.botao} url={supportedURL}>ASSISTIR ANIME</OpenURLButton>
                </View>
                <View style={style.divTr}>
                    <Text style={style.textEx}>Boku no Hero Academia - Filme</Text>
                    <Image style={style.imgEx} source='https://gkpb.com.br/wp-content/uploads/2021/12/gkpb-my-hero-academia-world-heroes-mission.jpg' />
                    <OpenURLButton style={style.botao} url={supportedURL2}>ASSISTIR ANIME</OpenURLButton>
                </View>
                <View style={style.divTr}>
                    <Text style={style.textEx}>Kimetsu no Yaiba- Seazon 2</Text>
                    <Image style={style.imgEx} source='https://saintscroll.com/wp-content/uploads/2021/12/Demon-Slayer-Kimetsu-no-Yaiba-Season-2.jpg' />
                    <OpenURLButton style={style.botao} url={supportedURL3}>ASSISTIR ANIME</OpenURLButton>
                </View>
                <View style={style.divTr}>
                    <Text style={style.textEx}>Jujutsu Kaisen - Filme</Text>
                    <Image style={style.imgEx} source='https://www.fajarpendidikan.co.id/wp-content/uploads/2022/01/Anime-Jujutsu-Kaisen-0-The-Movie.jpeg' />
                    <OpenURLButton url={supportedURL4}>ASSISTIR ANIME</OpenURLButton>
                </View>
            </View>

        </View>
    );
}
